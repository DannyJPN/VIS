﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PresentationLayer.WindowsFormsFaceTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
