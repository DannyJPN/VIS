﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PL_BL_DTO_Layer.FaceToBusinessDTOLib
{
    public class Class1
    {
    }
}
