﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace PL_BL_DTO_Layer.FaceToBusinessDTOLibTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
